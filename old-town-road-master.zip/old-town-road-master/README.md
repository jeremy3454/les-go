# Road Mesh Traffic Simulator

A Road Mesh Traffic Simulator project using Java

## Authors

| [<img src="https://avatars2.githubusercontent.com/u/26466516?v=3&s=150" width="150px;"/>](https://github.com/jpedroschmitz) | [<img src="https://avatars2.githubusercontent.com/u/26040800?v=3&s=150" width="150px;"/>](https://github.com/MarioFronza) |
| :-------------------------------------------------------------------------------------------------------------------------: | :-----------------------------------------------------------------------------------------------------------------------: |
|                                     [João Pedro S.](https://github.com/jpedroschmitz/)                                      |                                      [Mário Fronza](https://github.com/MarioFronza)                                       |

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.
