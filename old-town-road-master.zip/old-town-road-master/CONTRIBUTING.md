# Contributing

1. Fork this repository;
2. Create your feature branch: `git checkout -b new-feature`;
3. Commit your changes: `git commit -m 'feat: add some feature'`;
4. Push to the branch: `git push origin new-feature`.

**After your pull request is merged**, you can safely delete your branch.
